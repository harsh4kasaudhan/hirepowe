import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import MissionImg from "./../../assets/mission.jpg"
const MissionSection = () => {
  return (
    <div style={{ backgroundColor: "#fef0dc", padding: "60px 0" }}>
      <Container>
        <Row className="align-items-center">
          <Col md={6}>
            <div style={{ backgroundColor: "#fff" }}>
              <img
                src={MissionImg}
                alt="Our Mission"
                className="img-fluid"
              />
            </div>
          </Col>

          <Col md={6}>
            <h2 style={{ color: "#004225", fontSize: "48px", fontWeight: "bold" }}>
              Our mission
            </h2>
            <p style={{ fontSize: "18px", marginTop: "20px", color: "#002611" }}>
              <strong>HireProw Health Care</strong> is dedicated to delivering
              exceptional staffing solutions that connect top-tier healthcare
              professionals with facilities in need. Our mission emphasizes quality,
              reliability, and an unwavering commitment to improving patient care
              through innovative workforce solutions that foster partnerships and
              enhance operational efficiency in the healthcare sector.
            </p>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default MissionSection;
