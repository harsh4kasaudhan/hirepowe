import React from 'react'
import "./HeroSection.css"
const HeroSection = () => {
  return (
    <>
    <header className="bg-teal text-white py-5" style={{ backgroundColor: "#035306" }}>
        <div className="container text-center">
          <h1>We truly hireprow care about your family</h1>
          <p className="lead">
          HireProw Health Care delivers exceptional staffing solutions, ensuring top-tier professionals meet diverse health care needs efficiently and compassionately. Quality care starts with the right team.
          </p>
          {/* <div className="d-flex justify-content-center gap-3 mt-3">
            <img
              src="https://via.placeholder.com/50" // Replace with actual image
              className="rounded-circle"
              alt="User"
            />
            <img
              src="https://via.placeholder.com/50"
              className="rounded-circle"
              alt="User"
            />
          </div> */}
        </div>
      </header>
    </>
  )
}

export default HeroSection