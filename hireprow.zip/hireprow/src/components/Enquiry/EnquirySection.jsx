import React from "react";
import ContactImg from "./../../assets/contact.jpg"

const EnquirySection = () => {
  return (
    <section className="py-5" style={{ backgroundColor: "#fff" }}>
      <div className="container">
        <div
          className="d-flex flex-column flex-lg-row align-items-center justify-content-center p-4"
          style={{ backgroundColor: "#faedda", borderRadius: "8px" }}
        >
          {/* Left Image */}
          <div className="me-lg-4 mb-4 mb-lg-0">
            <img
              src={ContactImg}
              alt="Elder care"
              style={{ width: "100%", maxWidth: "350px", borderRadius: "5px" }}
            />
          </div>

          {/* Right Text Content */}
          <div className="text-center text-lg-start">
            <h2 className="mb-4" style={{ color: "#004d26", fontSize: "2.5rem", fontWeight: "bold" }}>
              Submit your enquiry form <br /> for prompt assistance.
            </h2>
            <a
              href="#enquiry"
              className="btn btn-success px-4 py-2"
              style={{ backgroundColor: "#004d26", fontWeight: "bold" }}
            >
              Click Here
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EnquirySection;
