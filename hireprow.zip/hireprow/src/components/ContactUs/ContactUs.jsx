import React from "react";
import contactImg from "./../../assets/contct.jpeg"

const ContactUs = () => {
  return (
    <section className="py-5" style={{ backgroundColor: "#fff" }}>
      <div className="container">
        <div
          className="d-flex flex-column flex-lg-row align-items-stretch"
          style={{ backgroundColor: "#f4f4f4", borderRadius: "8px", overflow: "hidden" }}
        >
            <div className="row">
                <div className="col-sm-6">
                     {/* Left - Text Content */}
          <div className="p-4 flex-grow-1">
            <h2 className="mb-4" style={{ color: "#004d26", fontSize: "2rem", fontWeight: 500 ,fontFamily:"auto"}}>
              Contact us
            </h2>
            <p style={{ fontSize: "16px" }}>
              For inquiries, please reach out to us at our office address or connect via phone and email.
            </p>

            <p><strong>Email:</strong> <span>infohireprow@gmail.com</span></p>
            <p><strong>Phone Number:</strong><span>+91 9519040090, +91 9236012827</span> </p>

            <p><strong>Address:</strong><span> Mahpur Ground floor, Lucknow Road Fatehpur Uttar Pradesh India - 212601</span></p>

            <p>
              <strong>Lucknow Branch Office Address:</strong><br />
             <span>11/161 Kamla Nivas Sector - 11<br />
              Rajkiya Kanya Inter College Indiranagar<br />
              Lucknow Uttar Pradesh - 226016</span> 
            </p>
          </div>
                </div>
                <div className="col-sm-6">
                    {/* Right - Image */}
          <div style={{ flex: 1, minHeight: "400px" }}>
            <img
              src={contactImg}
              alt="office"
              style={{ width: "100%", height: "440px", objectFit: "cover" }}
            />
          </div>
                </div>
            </div>
         

          
        </div>
      </div>
    </section>
  );
};

export default ContactUs;
