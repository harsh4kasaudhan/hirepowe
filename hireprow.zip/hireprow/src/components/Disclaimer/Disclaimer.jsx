import React from "react";
import "./Disclaimer.css"

const Disclaimer = () => {
  return (
    <section class="disclaimer-section">
      
        <div class="left-shape"></div>

        <div class="disclaimer-content">
            <h4>Disclaimer -</h4>
            <p>
                Please note that the counseling packages offered by Dr. Neha Mehta’s team do not include direct involvement 
                or sessions with Dr. Neha Mehta herself. Dr. Neha Mehta’s team consists of experienced professionals dedicated 
                to assisting you on your journey to better mental and emotional health.
            </p>
        </div>
    </section>
  );
};

export default Disclaimer;
