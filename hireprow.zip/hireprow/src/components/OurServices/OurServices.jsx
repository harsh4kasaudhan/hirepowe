import React from "react";
import { Container, Row, Col, Card } from "react-bootstrap";
import "./OurServices.css";
import { Link } from "react-router-dom";
const services = [
  {
    title: "Emergency Care",
    description:
      "Regular checkups ensure your health is monitored and maintained effectively.",
    image: "https://hireprow.com/images/976/7347092/box1.jpg",
  },
  {
    title: "Palliative Care",
    description:
      "Get immediate assistance when accidents or health crises arise. Compassionate care is essential.",
    image: "https://hireprow.com/images/976/7347112/box2.jpg",
  },
  {
    title: "Specialist Consultation",
    description:
      "Expert guidance tailored to your needs for optimal decisions and outcomes.",
    image: "https://hireprow.com/images/976/7347115/box3.jpg",
  },
  {
    title: "Physiotherapy Service",
    description:
      "Comprehensive physiotherapy services for optimal recovery and wellness.",
    image:
      "https://hireprow.com/images/976/15118292/crop-anonymous-medical-specialist-rubbing-shoulders-of-male-client-lying-on-couch-in-medical-salon.jpeg",
  },
  {
    title: "Maid Service",
    description:
      "Experience exceptional cleanliness and convenience with our professional maid service, tailored to meet all your home cleaning needs.",
    image:
      "https://hireprow.com/images/538/15055638/a-woman-in-a-red-uniform-cleans-indoors-with-a-blue-bucket-ensuring-a-spotless-environment.jpeg",
  },
  {
    title: "Cooking Service",
    description:
      "Delicious meals prepared for you, hassle-free cooking experience.",
    image:
      "https://hireprow.com/images/976/15055288/a-woman-in-an-apron-cooks-on-an-electric-stove-in-a-modern-kitchen-setting.jpeg",
  },
  {
    title: "Security Gaurd Service",
    description:
      "Reliable security guards ensuring safety and protection for everyone.",
    image:
      "https://hireprow.com/images/976/15055264/portrait-of-a-soldier-in-full-uniform-wearing-a-gas-mask-holding-a-weapon-exuding-a-tense-and-serious-mood.jpeg",
  },
  {
    title: "Injection On Call",
    description:
      "Experience convenient and professional injection services when you need them, right at your doorstep.",
    image:
      "https://hireprow.com/images/800/15072093/a-medical-professional-takes-a-blood-sample-from-a-patient-for-testing.jpeg",
  },
  {
    title: "Injection On Call",
    description:
      "Experience convenient and professional injection services when you need them, right at your doorstep.",
    image:
      "https://hireprow.com/images/976/15072147/a-doctor-measures-a-patient-s-blood-pressure-in-a-clinic-setting-focusing-on-healthcare-and-wellness.jpeg",
  },
];

const OurServices = () => {
  return (
    <>
      <Container className="text-center my-5">
        <h2 className="mb-4 text-success">Our Services</h2>
        <Row className="justify-content-center">
          {services.map((service, index) => (
            <Col md={4} sm={12} key={index} className="mb-4">
              <Card className="shadow-lg border-0">
                <div className="service-card-img">
                  <Card.Img variant="top" src={service.image} />
                </div>
                <Card.Body>
                  <div className="service-card-discription">
                    <h5 className="text-success">{service.title}</h5>
                    <p className="text-discription">{service.description}</p>
                    <a
  href="https://booking.hireprow.com/"
  target="_blank"
  rel="noopener noreferrer"
  className="fw-bold text-success"
>
  Book Now →
</a>

                  </div>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>
    </>
  );
};

export default OurServices;
