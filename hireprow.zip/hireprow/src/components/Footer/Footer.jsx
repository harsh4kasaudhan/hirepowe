import React from "react";
import { Container, Row, Col, Button } from "react-bootstrap";
import {
  FaFacebookF,
  FaTwitter,
  FaInstagram,
  FaYoutube,
} from "react-icons/fa";
import Logo from "./../../assets/hireprow.png"
import "./Footer.css"
const Footer = () => {
  return (
    <div className="pt-5 mt-5 footer-custom">
      <Container>
        <Row>
          <Col md={4}>
            <img
              src={Logo}
              alt="Logo"
              style={{ maxWidth: "180px" }}
            />
            <p className="mt-3">
            hireprow has 10 years of enriching experience in the field of
              counseling. She’s an accredited Psychologist by NIMHANS and
              International Affiliate with American Psychological Association.
            </p>
            <h5 className="mt-4">Follow us:</h5>
            <div className="d-flex gap-3 fs-5 mt-2">
              <FaFacebookF />
              <FaTwitter />
              <FaInstagram />
              <FaYoutube />
            </div>
          </Col>

          <Col md={2}>
          <div className="menu-links-footer">
          <h5>Links</h5>
            <ul className="list-unstyled footer-list1">
              <li>Home</li>
              <li>About Me</li>
              
              <li>Services</li>
             
              <li>Booking</li>
              <li>Contact</li>
            </ul>
          </div>
            
          </Col>

          <Col md={3}>
            <h5>More</h5>
            <ul className="list-unstyled footer-list2">
              <li>Disclaimer</li>
              <li>Terms & Conditions</li>
              <li>Privacy Policy</li>
              <li>Refund & Cancellation</li>
            </ul>
          </Col>

          <Col md={3}>
            <h5>Get in Touch</h5>
            <p>
              <strong>Address:</strong> M11/161 Kamla Nivas Sector - 11
Rajkiya Kanya Inter College Indiranagar
Lucknow Uttar Pradesh - 226016
            </p>
            <p>
              <strong>Email:</strong> infohireprow@gmail.com
            </p>
            <Button  className="text-white fw-bold w-100 btn-footer">
              Book Appointment
            </Button>
            {/* <p className="mt-3 small">
              <strong>Important Note*</strong>: Once you book an appointment
              your session will be scheduled in 24 Hours. For Emergency/Urgent
              sessions the charges will be doubled. Terms & Condition Apply
            </p> */}
          </Col>
        </Row>
      </Container>

      <div className="text-white text-center py-2" style={{ background: "linear-gradient(90deg,#198754,#035306)" }}>
        Copyright ©  2025 hireprow.com. All Rights Reserved.
      </div>
      {/* <div className="text-center py-2 text-white" style={{ background: "linear-gradient(90deg,#1ea7b8,#9183e5)" }}>
        Designed and Promoted By Digital Chaabi
        <br />
        <img
          src="https://drnehamehta.com/assets/images/dc.png"
          alt="Digital Chaabi"
          height="30"
          className="mt-2"
        />
      </div> */}
    </div>
  );
};

export default Footer;
