import React from 'react'
import Map1Img from "./../../assets/map1.jpeg";
import Map2Img from "./../../assets/map2.jpeg";
import "./Locations.css"
const Locations = () => {
  return (
    <>
    <section className="py-5">
  <div className="container">
    {/* Fatehpur Office */}
    <div className="row align-items-center mb-5">
      <div className="col-md-7">
        <p className="text-muted-lkns">
          Our office in Fatehpur is conveniently located, making it easily accessible for clients and visitors alike. This dedicated workspace is designed to foster collaboration and innovation, ensuring that our team can effectively serve your needs. Within this welcoming environment, we focus on delivering exceptional service and support.
        </p>
        <h5 className="text-success-location mt-4">▸ Fatehpur Office Address</h5>
        <h6 className="fw-bold-loaction-text mt-2">
        ▸ Mahpur Ground floor, Lucknow Road Fatehpur Uttar <br/>Pradesh India - 212601
        </h6>
      </div>
      <div className="col-md-5">
        <img
          src={Map1Img}
          alt="Fatehpur Map"
          className="img-fluid rounded shadow"
        />
      </div>
    </div>

    {/* Lucknow Office */}
    <div className="row align-items-center">
      <div className="col-md-7">
        <p className="text-muted-lkns">
          Our office in Lucknow is conveniently located, making it easily accessible for clients and visitors alike. This dedicated workspace is designed to foster collaboration and innovation, ensuring that our team can effectively serve your needs. Within this welcoming environment, we focus on delivering exceptional service and support.
        </p>
        <h5 className="text-success-location mt-4">▸ Lucknow Office Address</h5>
        <h6 className="fw-bold-loaction-text mt-2">
        ▸Lucknow Branch Office Add - 11/161 Kamla Nivas Sector<br />
          - 11 Rajkiya Kanya Inter College Indiranagar Lucknow Uttar Pradesh - 226016
        </h6>
      </div>
      <div className="col-md-5">
        <img
         src={Map2Img}
          alt="Lucknow Map"
          className="img-fluid rounded shadow"
        />
      </div>
    </div>
  </div>
</section>

    </>
  )
}

export default Locations;