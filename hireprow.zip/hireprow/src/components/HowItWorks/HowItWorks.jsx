import React from "react";
import { Container, Row, Col, Accordion } from "react-bootstrap";
import ImgLeft from "./../../assets/img-left.jpg"
import ImgRight from "./../../assets/img-right.jpg"
import "./HowItWorks.css"
const HowItWorks = () => {
  return (
    <div style={{ backgroundColor: "#fff", padding: "60px 0" }}>
      <Container>
        <Row>
          <Col md={6}>
            <h2 style={{ color: "#004225", fontSize: "52px", fontFamily:"sans-sarif" }}>
              How it works
            </h2>
            <p style={{ fontSize: "16px", color: "#002611", marginTop: "20px" }}>
              <strong>HireProw</strong> connects healthcare professionals with employers
              through a streamlined platform, facilitating talent matching, job postings,
              and application management for efficient hiring.
            </p>

            <Accordion defaultActiveKey="0" flush>
              <Accordion.Item eventKey="0">
                <Accordion.Header>
                 <span className="accord-head-text">1. Evaluation & Diagnosis</span> 
                </Accordion.Header>
                <Accordion.Body>
                  Assessment and diagnosis are crucial for understanding health conditions,
                  enabling tailored treatment plans and improving patient outcomes through
                  precise identification of issues.
                </Accordion.Body>
              </Accordion.Item>

              <Accordion.Item eventKey="1">
                <Accordion.Header>
                  <span className="accord-head-text">2. Weekly Care Plan</span>
                </Accordion.Header>
                <Accordion.Body>
                Discover personalized weekly care plans tailored to your needs, ensuring consistent support and fostering well-being through structured routines and skilled guidance for optimal health.
                </Accordion.Body>
              </Accordion.Item>

              <Accordion.Item eventKey="2">
                <Accordion.Header>
                <span className="accord-head-text"> 3. Start of the Care Journey</span> 
                </Accordion.Header>
                <Accordion.Body>
                Embark on your Care Journey today, where compassionate support and tailored solutions meet to enhance well-being and foster meaningful connections. Experience transformation and care like never before
                </Accordion.Body>
              </Accordion.Item>
            </Accordion>
          </Col>

          <Col md={6}>
            <div className="d-flex flex-column gap-3">
              <img
                src={ImgLeft}
                className="img-fluid rounded how-work-it-left-img"
                
              />
              <img
                src={ImgRight}
                alt="Care Plan"
                className="img-fluid rounded how-work-it-right-img"
              />
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default HowItWorks;
