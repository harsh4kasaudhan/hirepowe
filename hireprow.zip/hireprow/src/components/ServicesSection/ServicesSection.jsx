import React from "react";
import expImg from "./../../assets/years.png";
import docImg from "./../../assets/nehamehta.png";
import disountImg from "./../../assets/discount.gif";
import grpImg from "./../../assets/doctor2.png";

import "./ServicesSection.css";
import { IoLocationSharp } from "react-icons/io5";
const ServicesSection = () => {
  return (
    <>
      <section className="py-3" style={{ background: "#f4fbfc" }}>
        <div className="container">
          <div className="section-div">
            <div className="sect-head-div">
              <div className="row">
                <div className="col-sm-6">
                  <h2 className="text-center mb-4 selct-opt">
                    Please select your preferred option?
                  </h2>
                </div>
                <div className="col-sm-6">
                  <h2 className="text-center mb-4">
                    {" "}
                    <span className="lang-serv">
                      🌐 ENG| हिंदी | ਪੰਜਾਬੀ | हरयाणवी |
                      <span>
                        <IoLocationSharp />
                      </span>{" "}
                      Hisar, India
                    </span>{" "}
                  </h2>
                </div>
              </div>
            </div>

            <div className="row g-5">
              {/* First Card */}
              <div className="col-md-6">
                <div className="card border rounded shadow-sm p-4 left-card-doctor mt-4">
                  <h4 className="doc-card-1-hed">
                    Personalized Consultation with
                  </h4>
                  <h3 className="fw-bold doc-name">Dr. Neha Mehta</h3>
                  <p className="text-muted">
                    Consultant Psychologist, Clinical Psychologist
                  </p>
                  <div className="doc-card-box">
                    <div className="doc-card-box-left">
                      <img
                        src={expImg}
                        alt="Experience"
                        className="mb-3"
                        width="180px"
                      />
                      <p className="doct-fee">
                        <span>Starting From</span> <br />{" "}
                        <strong>Rs. 3,000.00/30min*</strong>
                      </p>
                      <p className="doct-comunication-text">
                        <span>Communication options:</span>
                      </p>
                      <div className="d-flex gap-2 all-btn">
                        <button className="btn btn-outline-success">
                          <p>🏥</p> <p>Clinic</p>
                        </button>
                        <button className="btn btn-outline-success">
                          <p>📞</p> <p>Call</p>
                        </button>
                        <button className="btn btn-outline-success">
                          <p>💬</p> <p>Chat</p>
                        </button>
                      </div>
                      <button className="btn btn-success mt-3 book-btn">
                        BOOK AN APPOINTMENT
                      </button>
                    </div>
                    <div className="doc-card-box-right">
                      <img src={docImg} alt="doct-image" className="doct-img" />
                    </div>
                  </div>
                </div>
              </div>
              {/* Second Card */}
              <div className="col-md-6">
                <div className="card border rounded shadow-sm p-4 mt-4 right-card-doctor">
                  <div className="doct-second-card-box-head">
                    <div className="second-card-box-left-head">
                      <h3 className="fw-bold tail-pack-text">
                        Tailored Packages by
                      </h3>
                      <h4 className="dr-name">
                        Dr. Neha Mehta's{" "}
                        <span className="text-primary-colr">Team</span>
                      </h4>
                    </div>
                    <div className="second-card-box-right-head">
                      <img
                        src={disountImg}
                        alt="discount"
                        className="discount-img"
                      />
                    </div>
                  </div>

                  <p className="second-card-text">
                    Sexual and Mental health counselling <br />
                    by Neha Mehta's Team
                  </p>
                  <ul className="list-unstyled">
                    <li>
                      <span className="ul-icons">✔</span>{" "}
                      <span className="ul-text">Adaptable sessions.</span>
                    </li>
                    <li>
                      <span className="ul-icons">✔</span>{" "}
                      <span className="ul-text">Affordable rates.</span>
                    </li>
                    <li>
                      <span className="ul-icons">✔</span>{" "}
                      <span className="ul-text">
                        Valid for days with flexibility.
                      </span>
                    </li>
                  </ul>
                  <div className="second-card-comunicatin-box">
                    <div className="second-card-comunicatin-box-left">
                      <div className="communication-box-1">
                        <p>
                          <span>Communication options:</span>
                        </p>
                        <button className="btn btn-outline-success btn-call-chat">
                          📞 VOICE CHAT
                        </button>
                      </div>

                      <button className="btn btn-success mt-3 by-pkg-btn">
                        BUY PACKAGE
                      </button>
                    </div>
                    <div className="second-card-comunicatin-box-right">
                      <img src={grpImg} alt="group-img"  className="second-card-grp-img"/>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default ServicesSection;
