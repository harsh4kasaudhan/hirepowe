import React from "react";
import Slider from "react-slick";
import Carousel from "react-bootstrap/Carousel";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
const testimonials = [
    {
      quote: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form...",
      name: "Jonathan Makenzie",
      role: "Patient",
    },
    {
      quote: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. It has survived not only five centuries...",
      name: "Emily Rose",
      role: "Client",
    },
    {
      quote: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout...",
      name: "Michael Smith",
      role: "Customer",
    },
  ];
  
const RviewTestimonials = () => {
    var settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1
      };
  return (
    <>
     <section className="py-5" style={{ background: "#fbeedd" }}>
      <div className="container">
        <h2 className="text-center mb-5" style={{ color: "#004d26", fontWeight: "bold" }}>
          What our clients say
        </h2>

        <Slider {...settings}>
          {testimonials.map((item, index) => (
            <Carousel.Item key={index}>
              <div className="d-flex justify-content-center">
                <div
                  className="card shadow-sm p-4"
                  style={{
                    maxWidth: "700px",
                    borderRadius: "16px",
                    background: "white",
                    border: "none",
                  }}
                >
                  <div className="text-center">
                    <div style={{ fontSize: "60px", color: "#ccc" }}>“</div>
                    <p className="lead text-dark">{item.quote}</p>
                    <div style={{ fontSize: "60px", color: "#ccc", marginTop: "-20px" }}>”</div>
                    <h5 className="mt-4 text-success mb-1">{item.name}</h5>
                    <p className="text-muted mb-0">{item.role}</p>
                  </div>
                </div>
              </div>
            </Carousel.Item>
          ))}
        </Slider>
      </div>
    </section>
    </>
  )
}

export default RviewTestimonials;