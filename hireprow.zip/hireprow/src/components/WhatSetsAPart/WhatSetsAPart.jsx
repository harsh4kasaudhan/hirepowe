import React from 'react'
import "./WhatSetsAPart.css"
import Calender from "./../../assets/icn1.png"
import Lab from "./../../assets/icn2.png"
import Mark from "./../../assets/icon3.png"
const WhatSetsAPart = () => {
  return (
    <>
    <section className=" py-5 text-center what-sets-main-box">
  <div className="container">
    <h6 className="mb-3 whats-sets-text-heding">What sets us apart</h6>
    <p className="mb-5 text-muted-whats-discrp">
      Our unique approach, commitment to quality, and personalized service distinguish us from competitors, ensuring an exceptional experience for every client.
    </p>

    <div className="row">
      <div className="col-md-4 mb-4">
        <div className="d-flex flex-column align-items-center">
          <i className="bi bi-calendar2-check display-4 mb-3 text-success"><img src={Calender} alt='icon-1'/></i>
          <h5 className="fw-semibold">Same / next-day<br/> appointments</h5>
          <p className="text-muted-icn1">Book same or next-day appointments for your convenience.</p>
        </div>
      </div>

      <div className="col-md-4 mb-4">
        <div className="d-flex flex-column align-items-center">
          <i className="bi bi-beaker-check display-4 mb-3 text-success">
            <img src={Lab} alt="icon2"/>
          </i>
          <h5 className="fw-semibold">Drop-in lab services at <br/>our offices</h5>
          <p className="text-muted-icn1">Visit our offices for convenient drop-in lab services.</p>
        </div>
      </div>

      <div className="col-md-4 mb-4">
        <div className="d-flex flex-column align-items-center">
          <i className="bi bi-geo-alt-fill display-4 mb-3 text-success">
            <img src={Mark} alt='icon3'/>
          </i>
          <h5 className="fw-semibold">6 convenient locations<br/> nationwide</h5>
          <p className="text-muted-icn1">Accessible locations spread across the nation.</p>
        </div>
      </div>
    </div>
  </div>
</section>

    </>
  )
}

export default WhatSetsAPart;