import React from 'react'
import { FaStar } from "react-icons/fa";
const reviews = [
    {
      name: "Aman Agarwal",
      image: "https://randomuser.me/api/portraits/men/32.jpg",
      text: "Dr. Neha Mehta and her team are a beacon of hope for those seeking support in sexual counseling. The packages they offer are not only affordable but also incredibly useful.",
    },
    {
      name: "Harsh Pundir",
      image: "https://randomuser.me/api/portraits/men/45.jpg",
      text: "I want to express my appreciation for Dr. Neha Mehta and her team. The affordability and usefulness of their services have been instrumental in my personal growth and well-being.",
    },
    {
      name: "Pranav Yadav",
      image: "https://randomuser.me/api/portraits/men/50.jpg",
      text: "Dr. Neha Mehta’s team and their packages have been a source of support and guidance for me. The affordability of their services has made seeking professional help a reality.",
    },
    {
      name: "Surabhi Verma",
      image: "https://randomuser.me/api/portraits/women/39.jpg",
      text: "I wholeheartedly recommend Dr. Neha Mehta for her exceptional counseling. Dr. Mehta’s professionalism and empathy create a welcoming environment.",
    },
    
  ];
const ClienntReview = () => {
    
  return (
    <>
<section className="py-5 bg-light">
      <div className="container">
        <h2 className="text-center text-primary">CLIENT REVIEWS</h2>
        <h3 className="text-center fw-bold">Who Done Session With Us</h3>

        <div className="row mt-4">
          {reviews.map((review, index) => (
            <div key={index} className="col-md-6 col-lg-3 mb-4">
              <div className="card p-3 h-100 shadow-sm">
                <div className="d-flex align-items-center mb-3">
                  <img
                    src={review.image}
                    alt={review.name}
                    className="rounded-circle me-3"
                    width="50"
                    height="50"
                  />
                  <div>
                    <h5 className="mb-0 text-primary">{review.name}</h5>
                    <div className="text-warning">
                      {[...Array(5)].map((_, i) => (
                        <FaStar key={i} />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-muted">{review.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
    </>
  )
}

export default ClienntReview