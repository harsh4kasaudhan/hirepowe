import { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import "bootstrap/dist/js/bootstrap.bundle.min.js";
import HomeScreens from './Screens/HomeScreens';

function App() {
  const [count, setCount] = useState(0);

  return (
    <Router>
      <Routes>
        {/* Default route (/) will redirect to /booking */}
        <Route path="/" element={<Navigate to="/booking" replace />} />

        {/* Booking screen */}
        <Route path="/booking" element={<HomeScreens />} />
      </Routes>
    </Router>
  );
}

export default App;
