import React from 'react'
import Navbar from '../components/Navbar/Navbar';
import HeroSection from '../components/HeroSection/HeroSection';

import OurServices from '../components/OurServices/OurServices';
import Footer from '../components/Footer/Footer';
import MissionSection from '../components/OurMission/MissionSection ';
import HowItWorks from '../components/HowItWorks/HowItWorks';
import WhatSetsAPart from '../components/WhatSetsAPart/WhatSetsAPart';
import Locations from '../components/Locations/Locations';
import RviewTestimonials from '../components/RviewTestimonials/RviewTestimonials';
import EnquirySection from '../components/Enquiry/EnquirySection';
import ContactUs from '../components/ContactUs/ContactUs';

const HomeScreens = () => {
  return (
    <div className='container-fluid m-0 p-0'>
        <Navbar/>
        <HeroSection/>
      
        <OurServices/>
        <MissionSection/>
      <HowItWorks/>
       <WhatSetsAPart/>
       <Locations/>
       <RviewTestimonials/>
       <EnquirySection/>
       <ContactUs/>
        <Footer/>
    </div>
  )
}

export default HomeScreens;